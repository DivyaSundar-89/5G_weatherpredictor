package weather.predictor.service;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

public interface WeatherPredictorService
{
    Response getTestWeatherStat(@Context UriInfo uri);

    Response getLiveWeatherStat(@Context UriInfo uri);
}
