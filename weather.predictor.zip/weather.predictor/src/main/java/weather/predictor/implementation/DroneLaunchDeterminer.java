package weather.predictor.implementation;

public class DroneLaunchDeterminer
{
    private int error_score = 1;
    private int initial_score = 0;
    private int signal_strength = 1;

    public Boolean droneLaunchStatus(WeatherStatPOJO pojo, boolean signal)
    {
        int reward = 0;
        float temp = Float.parseFloat(pojo.getTemperature());
        int pressure = Integer.parseInt(pojo.getPressure());
        float wind_speed = Float.parseFloat(pojo.getWind_speed());
        if (!signal) // Weak signal-strength detected from sensors
        {
            if (temp >= 150 && pressure >= 500 && wind_speed <= 10)
            {
                reward = 0;
                signal_strength = 0;
                return learnFinalRewardScore(reward, signal_strength);
            }
            else
            {
                reward = 1;
                signal_strength = 1;
                return learnFinalRewardScore(reward, signal_strength);
            }
        }
        else if (temp <= 80 && pressure <= 500 && wind_speed >= 80) // As the cyclone approaches, temperature and pressure drop, but wind speed gradually rises
        {
            return getRewardScoreValue(pojo, signal);
        }
        else if (wind_speed >= 30 && pressure >= 500) // Cyclone starts moving
        {
            return getRewardScoreValue(pojo, signal);
        }
        else if (wind_speed <= 10 && temp >= 150 && pressure >= 500) // cyclone drifted away slightly
        {
            return getRewardScoreValue(pojo, signal);
        }
        return false;
    }

    private Boolean getRewardScoreValue(WeatherStatPOJO pojo, boolean signal)
    {
        int reward;
        if (signal)
        {
            signal_strength = 1;
            reward = 1;
        }
        else
        {
            reward = 0;
            signal_strength = 0;
        }
        return learnFinalRewardScore(reward, signal_strength);
    }

    private Boolean learnFinalRewardScore(int reward, int signal_strength)
    {
        if (initial_score + (reward * error_score + signal_strength) > 0)
        {
            return true;
        }
        return false;
    }
}
