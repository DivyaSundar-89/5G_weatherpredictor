package weather.predictor.implementation;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;

import javax.ws.rs.core.Application;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Reference;
import org.apache.felix.scr.annotations.ReferenceCardinality;
import org.apache.felix.scr.annotations.ReferencePolicy;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;
import org.osgi.service.http.HttpService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import weather.predictor.service.WeatherPredictorService;

@Component
public class RestConfigurator extends Application
{
    private static Logger LOG = LoggerFactory.getLogger(RestConfigurator.class);
    private final Object lock = new Object();
    protected final static String CONTEXT_PATH = "/aichallenge";
    protected final static String WARN_MESSAGE = "HttpService reference null, hence not registering the REST resources";
    List<Object> resources = new ArrayList<Object>();
    ServletContainer servletContainer;

    @Reference (name = "Weather Predictor Service", policy = ReferencePolicy.DYNAMIC, cardinality = ReferenceCardinality.MANDATORY_UNARY, referenceInterface = WeatherPredictorService.class, bind = "bindWeatherPredictorService", unbind = "unbindWeatherPredictorService")
    private WeatherPredictorService weatherPredictorService;

    @Reference (name = "HttpService", policy = ReferencePolicy.DYNAMIC, cardinality = ReferenceCardinality.MANDATORY_UNARY, referenceInterface = HttpService.class, bind = "bindHttpService", unbind = "unbindHttpService")
    private HttpService service;

    protected void bindWeatherPredictorService(WeatherPredictorService service)
    {
        weatherPredictorService = service;
        resources.add(weatherPredictorService);
    }

    protected void unbindWeatherPredictorService(WeatherPredictorService service)
    {
        resources.remove(service);
        weatherPredictorService = null;
    }

    protected void bindHttpService(HttpService httpService)
    {
        service = httpService;
    }

    protected void unbindHttpService(HttpService httpService)
    {
        if (service.equals(httpService))
        {
            service = null;
        }
    }

    @Activate
    public void activate()
    {
        if (service != null)
        {
            try
            {
                Dictionary<String, String> dict = new Hashtable<>();
                ResourceConfig config = new ResourceConfig();
                ResourceConfig.forApplication(this);
                Set<Object> obj = getSingletons();
                for (Object object : obj)
                {
                    config.register(object);
                }
                servletContainer = new ServletContainer(config);
                service.registerServlet(CONTEXT_PATH, servletContainer, dict, service.createDefaultHttpContext());
            }
            catch (Exception e)
            {
                LOG.error("Exception in registering servlet container {}", e);
            }
        }
        else
        {
            LOG.warn(WARN_MESSAGE);
        }

    }

    @Deactivate
    public void deActivate()
    {
        if (service != null)
        {
            service.unregister(CONTEXT_PATH);
        }
    }

    @Override
    public Set<Object> getSingletons()
    {
        synchronized (this.lock)
        {
            Set currentResources = getResources();
            return currentResources;
        }
    }

    private Set<Object> getResources()
    {
        Set singletons = new HashSet(super.getSingletons());
        singletons.addAll(resources);
        return singletons;
    }
}
