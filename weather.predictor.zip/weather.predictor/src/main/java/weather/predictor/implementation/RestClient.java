package weather.predictor.implementation;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RestClient
{
    private static final Logger LOG = LoggerFactory.getLogger(RestClient.class);
    private String myRestUrl = null;
    private static RestClient instance;

    public static RestClient getInstance()
    {
        if (instance == null)
        {
            instance = new RestClient();
        }
        return instance;
    }

    public RestClient()
    {
        try
        {
            myRestUrl = "http://api.openweathermap.org/data/2.5/weather";
        }
        catch (Exception e)
        {
            LOG.error("Exception activating RestClient {}", e);
        }
    }

    private String updateLatLong(String lat, String lon)
    {
        StringBuilder builder = new StringBuilder();
        builder.append(myRestUrl);
        return builder.toString();
    }

    public String doGet(String lat, String lon)
    {
        Response response;
        try
        {
            String restUrl = updateLatLong(lat, lon);
            Client client = ClientBuilder.newBuilder().build();
            String builder = UriBuilder.fromPath(restUrl).queryParam("APPID", "95be668a196e1078859a88106d130860").queryParam("lat", lat).queryParam("lon", lon).toString();
            WebTarget webTarget = client.target(builder.substring(0, builder.length() - 3));
            Builder invocationBuilder = webTarget.request();
            response = invocationBuilder.get();
            String responseContent = response.readEntity(String.class);
            return responseContent;
        }
        catch (Exception e)
        {
            LOG.error("Exception invoking rest api {} ", e);
        }
        return null;
    }
}
