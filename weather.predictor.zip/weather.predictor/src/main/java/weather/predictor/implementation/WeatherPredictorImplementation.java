package weather.predictor.implementation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Dictionary;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import org.apache.felix.scr.annotations.Activate;
import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.Deactivate;
import org.apache.felix.scr.annotations.Service;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import weather.predictor.service.WeatherPredictorService;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mysql.cj.jdbc.Driver;

@Component (label = "Weather Predictor", description = "weather predictor component and service", immediate = true)
@Service
@Path ("/v1")
public class WeatherPredictorImplementation implements WeatherPredictorService
{
    private static final Logger LOG = LoggerFactory.getLogger(WeatherPredictorImplementation.class);
    Map<String, LatLongPOJO> latLongMapper = new ConcurrentHashMap<String, LatLongPOJO>();
    static Connection con;
    private static final String CONFIG = "customconfig";
    String user, password, port = null;
    RestClient restClient = null;

    /**
     * Activates this Component class
     *
     * @param bundleContext
     *            context
     */
    @Activate
    public void activate(BundleContext bundleContext)
    {
        try
        {
            restClient = RestClient.getInstance();
            ServiceReference serviceReference = bundleContext.getServiceReference(ConfigurationAdmin.class.getName());
            if (serviceReference != null)
            {
                ConfigurationAdmin configAdmin = (ConfigurationAdmin) bundleContext.getService(serviceReference);
                Configuration configuration = configAdmin.getConfiguration(CONFIG);
                Dictionary<String, Object> configProperties = configuration.getProperties();
                if (configProperties != null)
                {
                    user = configProperties.get("user").toString();
                    password = configProperties.get("password").toString();
                    port = configProperties.get("port").toString();
                }
            }
        }
        catch (Exception e)
        {
            LOG.error("Exception reading configuration file {}", e);
        }
        try
        {
            Driver driver = Driver.class.newInstance();
            con = DriverManager.getConnection("jdbc:mysql://localhost:" + port + "/ai", user, password);
            Statement st = con.createStatement();
            ResultSet res = st.executeQuery("select * from location_latlongmapper");
            while (res.next())
            {
                String area = res.getString("area");
                String lat = res.getString("lat");
                String lon = res.getString("lon");
                LatLongPOJO pojo = new LatLongPOJO();
                pojo.setLatitude(lat);
                pojo.setLongitude(lon);
                latLongMapper.put(area, pojo);
            }
        }
        catch (Exception e)
        {
            LOG.error("Exception trying to connect with JDBC driver {}", e);
        }
    }

    /**
     * Deactivate this Component class
     */
    @Deactivate
    public void deactivate()
    {
        try
        {
            con.close();
        }
        catch (SQLException e)
        {
            LOG.error("SQLException {}", e);
        }
    }

    @Override
    @GET
    @Path ("/testweatherstat")
    @Produces (MediaType.APPLICATION_JSON)
    public Response getTestWeatherStat(@Context UriInfo uri)
    {
        String location = null;
        String ASU = null;
        boolean isStrongSignal = false;
        MultivaluedMap<String, String> queryParamMap = uri.getQueryParameters();
        if (queryParamMap != null)
        {
            location = queryParamMap.getFirst("location");
            ASU = queryParamMap.getFirst("ASU");
        }
        if (location == null)
        {
            LOG.error("Query parameter location not received in the request, failing the REST call with 400 response");
            return Response.status(400).entity("").build();
        }
        LatLongPOJO pojo = latLongMapper.get(location);
        StringBuilder builder = new StringBuilder();
        if (ASU == null)
        {
            isStrongSignal = false;
        }
        else
        {
            GetSignalStrength signalStrength = new GetSignalStrength();
            signalStrength.setASU(Integer.parseInt(ASU));
            isStrongSignal = signalStrength.isSignalStrong();
        }
        DroneLaunchDeterminer determiner = new DroneLaunchDeterminer();
        String resp = restClient.doGet(pojo.getLatitude(), pojo.getLongitude());
        WeatherStatPOJO weatherPojo = new ResponseParser().getWeatherStat(resp, pojo.getLatitude(), pojo.getLongitude());
        builder.append("WeatherConditionInGivenArea").append(":").append(weatherPojo.getWeather());
        builder.append("\n").append("LaunchDrone").append(":").append(determiner.droneLaunchStatus(weatherPojo, isStrongSignal));
        String str = null;
        try
        {
            str = new ObjectMapper().writeValueAsString(builder.toString());
        }
        catch (Exception e)
        {
            LOG.error("Error parsing the Json response {}", e);
        }
        return Response.status(200).entity(str).build();
    }

    @Override
    @GET
    @Path ("/liveweatherstat")
    @Produces (MediaType.APPLICATION_JSON)
    public Response getLiveWeatherStat(@Context UriInfo uri)
    {
        String lat = null;
        String lon = null;
        String ASU = null;
        boolean isStrongSignal = false;
        MultivaluedMap<String, String> queryParamMap = uri.getQueryParameters();
        if (queryParamMap != null)
        {
            lat = queryParamMap.getFirst("latitude");
            lon = queryParamMap.getFirst("longitude");
            ASU = queryParamMap.getFirst("ASU");
        }
        if (lat == null || lon == null)
        {
            LOG.error("Either latitude or longitude received in the request is null, failing the REST call with 400 response");
            return Response.status(400).entity("").build();
        }
        if (ASU == null)
        {
            isStrongSignal = false;
        }
        else
        {
            GetSignalStrength signalStrength = new GetSignalStrength();
            signalStrength.setASU(Integer.parseInt(ASU));
            isStrongSignal = signalStrength.isSignalStrong();
        }
        StringBuilder builder = new StringBuilder();
        DroneLaunchDeterminer determiner = new DroneLaunchDeterminer();
        String resp = restClient.doGet(lat, lon);
        WeatherStatPOJO weatherPojo = new ResponseParser().getWeatherStat(resp, lat, lon);
        builder.append("WeatherConditionInGivenArea").append(":").append(weatherPojo.getWeather());
        boolean determineDroneLaunch = determiner.droneLaunchStatus(weatherPojo, isStrongSignal);
        builder.append("\n").append("LaunchDrone").append(":").append(determineDroneLaunch);
        String str = null;
        try
        {
            str = new ObjectMapper().writeValueAsString(builder.toString());
        }
        catch (Exception e)
        {
            LOG.error("Error parsing the Json response {}", e);
        }
        updateTableinDB(weatherPojo, determineDroneLaunch, lat, lon);
        return Response.status(200).entity(str).build();
    }

    private void updateTableinDB(WeatherStatPOJO pojo, boolean launchDrone, String lat, String lon)
    {
        try
        {
            String query = " insert into live_table (area, lat, lon, weather, temp, pressure, humidity, wind_speed, launchDrone)"
                    + " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setString(1, pojo.getArea());
            preparedStmt.setString(2, lat);
            preparedStmt.setString(3, lon);
            preparedStmt.setString(4, pojo.getWeather());
            preparedStmt.setString(5, pojo.getTemperature());
            preparedStmt.setString(6, pojo.getPressure());
            preparedStmt.setString(7, pojo.getHumidity());
            preparedStmt.setString(8, pojo.getWind_speed());
            preparedStmt.setString(9, String.valueOf(launchDrone));
            preparedStmt.execute();
        }
        catch (Exception e)
        {
            LOG.error("Exception while writing to table {}", e);
        }
    }
}
