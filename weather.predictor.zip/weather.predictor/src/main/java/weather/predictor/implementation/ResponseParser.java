package weather.predictor.implementation;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class ResponseParser
{

    public WeatherStatPOJO getWeatherStat(String responseContent, String lat, String lon)
    {
        JsonObject object = new JsonParser().parse(responseContent).getAsJsonObject();
        JsonElement element = object.get("weather").getAsJsonArray();
        JsonObject weatherData = (JsonObject) element.getAsJsonArray().get(0);
        String weather = weatherData.get("main").getAsString();
        JsonElement mn = object.get("main");
        String temp = mn.getAsJsonObject().get("temp").getAsString();
        String pressure = mn.getAsJsonObject().get("pressure").getAsString();
        String humidity = mn.getAsJsonObject().get("humidity").getAsString();
        String wind = object.get("wind").getAsJsonObject().get("speed").getAsString();
        String area = object.get("name").getAsString();
        WeatherStatPOJO pojo = new WeatherStatPOJO();
        pojo.setArea(area);
        pojo.setHumidity(humidity);
        pojo.setPressure(pressure);
        pojo.setTemperature(temp);
        pojo.setWeather(weather);
        pojo.setWind_speed(wind);
        return pojo;
    }
}
