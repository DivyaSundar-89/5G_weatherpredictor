package weather.predictor.implementation;

public class GetSignalStrength
{
    private int ASU;

    public boolean isSignalStrong()
    {
        if (ASU >= 0 && ASU <= 99)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public void setASU(int aSU)
    {
        ASU = aSU;
        DBM = -113 + (2 * ASU);
    }

    public int getDBM()
    {
        return DBM;
    }

    private int DBM;
}
