package weather.predictor.implementation;

public class WeatherStatPOJO
{
    private String area;

    public String getArea()
    {
        return area;
    }

    public void setArea(String area)
    {
        this.area = area;
    }

    public String getWeather()
    {
        return weather;
    }

    public void setWeather(String weather)
    {
        this.weather = weather;
    }

    public String getTemperature()
    {
        return temperature;
    }

    public void setTemperature(String temperature)
    {
        this.temperature = temperature;
    }

    public String getPressure()
    {
        return pressure;
    }

    public void setPressure(String pressure)
    {
        this.pressure = pressure;
    }

    public String getHumidity()
    {
        return humidity;
    }

    public void setHumidity(String humidity)
    {
        this.humidity = humidity;
    }

    public String getWind_speed()
    {
        return wind_speed;
    }

    public void setWind_speed(String wind_speed)
    {
        this.wind_speed = wind_speed;
    }

    private String weather;
    private String temperature;
    private String pressure;
    private String humidity;
    private String wind_speed;
}
